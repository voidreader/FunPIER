var searchData=
[
  ['room',['Room',['../classjnamobile_1_1mmm_1_1_room_event_args.html#a53ffdbfe096b65fbd3ee4c549527cc9b',1,'jnamobile::mmm::RoomEventArgs']]],
  ['roomname',['RoomName',['../classjnamobile_1_1mmm_1_1_map_room.html#aea52b19b901751e7aa2f5a7b3ebe3851',1,'jnamobile::mmm::MapRoom']]]
];
