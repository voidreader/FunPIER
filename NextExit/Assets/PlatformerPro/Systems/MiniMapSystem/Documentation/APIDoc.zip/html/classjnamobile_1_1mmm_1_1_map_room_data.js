var classjnamobile_1_1mmm_1_1_map_room_data =
[
    [ "MapRoomData", "classjnamobile_1_1mmm_1_1_map_room_data.html#add255e640aef0cca3942242ff83c6ca1", null ],
    [ "MapRoomData", "classjnamobile_1_1mmm_1_1_map_room_data.html#a650d54254f07ee21a2bfa443e6a092b8", null ],
    [ "Apply", "classjnamobile_1_1mmm_1_1_map_room_data.html#a2bd599d6a1b7b5450b65aca087435077", null ],
    [ "DoPoiScan", "classjnamobile_1_1mmm_1_1_map_room_data.html#a40f20983e2d8ee8f911424676f36fceb", null ],
    [ "Equals", "classjnamobile_1_1mmm_1_1_map_room_data.html#a7844fa19a3343c1876d52915b67bc19e", null ],
    [ "GetHashCode", "classjnamobile_1_1mmm_1_1_map_room_data.html#a84b94e084663672ff442bcabbb887b9f", null ],
    [ "_position", "classjnamobile_1_1mmm_1_1_map_room_data.html#a85182c4be0614f0beeac97abbb3b4eea", null ],
    [ "colorOverride", "classjnamobile_1_1mmm_1_1_map_room_data.html#a0b2dc02619e567bc814e0071510ec583", null ],
    [ "fqn", "classjnamobile_1_1mmm_1_1_map_room_data.html#aca7faa567c344bc08f4b6856006efb92", null ],
    [ "height", "classjnamobile_1_1mmm_1_1_map_room_data.html#aad9289e4b1ee6eef0d66c6802cd9683c", null ],
    [ "pointsOfInterest", "classjnamobile_1_1mmm_1_1_map_room_data.html#a9855199c634ac023e34b4286116d3b17", null ],
    [ "revealed", "classjnamobile_1_1mmm_1_1_map_room_data.html#aae8a621c537af65d6920521548638ea3", null ],
    [ "shortName", "classjnamobile_1_1mmm_1_1_map_room_data.html#a27cc4c7de20188d71a4f195512cf9560", null ],
    [ "spriteName", "classjnamobile_1_1mmm_1_1_map_room_data.html#a4a89ff6fcabeeb09ce26500ed840cff4", null ],
    [ "width", "classjnamobile_1_1mmm_1_1_map_room_data.html#a2dbae28f7514b97805cb7b31078dab76", null ],
    [ "MapRoom", "classjnamobile_1_1mmm_1_1_map_room_data.html#a0677c4ea7068bb2ecdf3d7d4ed364fe1", null ],
    [ "OverrideSprite", "classjnamobile_1_1mmm_1_1_map_room_data.html#a90054a644f2f2a8fbc5733ea7cc6209d", null ],
    [ "PointsOfInterest", "classjnamobile_1_1mmm_1_1_map_room_data.html#a89c28bc930b2dcfa296e2a0401be5348", null ],
    [ "position", "classjnamobile_1_1mmm_1_1_map_room_data.html#af2b1cda1e3a83fa29da75f88a9f8c56d", null ]
];