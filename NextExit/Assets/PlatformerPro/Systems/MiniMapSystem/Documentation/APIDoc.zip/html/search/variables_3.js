var searchData=
[
  ['category',['category',['../classjnamobile_1_1mmm_1_1_point_of_interest_data.html#abb2804c575059b14225cdecfd3b855fd',1,'jnamobile.mmm.PointOfInterestData.category()'],['../classjnamobile_1_1mmm_1_1_point_of_interest.html#af3ef0b3a6a40e37bc98b0b6b69b8edc7',1,'jnamobile.mmm.PointOfInterest.category()']]],
  ['color',['color',['../classjnamobile_1_1mmm_1_1_point_of_interest_data.html#a7aba95250148d9a2bde12eec14a00261',1,'jnamobile.mmm.PointOfInterestData.color()'],['../classjnamobile_1_1mmm_1_1_point_of_interest.html#a7b822fc30cc2a97f516e5476a70fa90c',1,'jnamobile.mmm.PointOfInterest.color()']]],
  ['coloroverride',['colorOverride',['../classjnamobile_1_1mmm_1_1_map_room_data.html#a0b2dc02619e567bc814e0071510ec583',1,'jnamobile.mmm.MapRoomData.colorOverride()'],['../classjnamobile_1_1mmm_1_1_map_room.html#a2da0c97fd63ce1c88f8b53e751307d0b',1,'jnamobile.mmm.MapRoom.colorOverride()']]],
  ['currentroom',['currentRoom',['../classjnamobile_1_1mmm_1_1_map_manager.html#afee444c9a1f540e9e89e02e845ae5811',1,'jnamobile::mmm::MapManager']]],
  ['currentroomindicator',['currentRoomIndicator',['../classjnamobile_1_1mmm_1_1_u_i_map_content.html#aa36380ce35bf1182be6c46d7f2624d72',1,'jnamobile::mmm::UIMapContent']]]
];
