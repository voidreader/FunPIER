var searchData=
[
  ['gridsize',['gridSize',['../classjnamobile_1_1mmm_1_1_map_manager.html#a9988c583105a1004be6699d453e1cfa5',1,'jnamobile::mmm::MapManager']]]
];
