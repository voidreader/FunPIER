var searchData=
[
  ['icon',['icon',['../classjnamobile_1_1mmm_1_1_point_of_interest_data.html#a704aaed3c4ab39589620f4c0bb561806',1,'jnamobile::mmm::PointOfInterestData']]],
  ['instance',['Instance',['../classjnamobile_1_1mmm_1_1_map_manager.html#ab99e4a664eaddd6028f8f28eb126c9ee',1,'jnamobile.mmm.MapManager.Instance()'],['../classjnamobile_1_1mmm_1_1_sprite_dictionary.html#aba984f3d1d6606ed56dc5cb417b97625',1,'jnamobile.mmm.SpriteDictionary.Instance()']]]
];
