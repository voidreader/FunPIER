var dir_331fde15a789d7c961bdeb4148ecc6be =
[
    [ "SpriteAssignerAttribute.cs", "_sprite_assigner_attribute_8cs.html", [
      [ "SpriteAssignerAttribute", "class_sprite_assigner_attribute.html", "class_sprite_assigner_attribute" ]
    ] ]
];