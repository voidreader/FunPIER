var annotated =
[
    [ "jnamobile", "namespacejnamobile.html", "namespacejnamobile" ],
    [ "MMMSpriteAssigner", "class_m_m_m_sprite_assigner.html", "class_m_m_m_sprite_assigner" ],
    [ "SpriteAssignerAttribute", "class_sprite_assigner_attribute.html", "class_sprite_assigner_attribute" ]
];