var classjnamobile_1_1mmm_1_1_point_of_interest_event_args =
[
    [ "PointOfInterestEventArgs", "classjnamobile_1_1mmm_1_1_point_of_interest_event_args.html#a3823ec21383fb9c66e7918418c5172fd", null ],
    [ "PointOfInterest", "classjnamobile_1_1mmm_1_1_point_of_interest_event_args.html#aaa6b5cc15723148689f10c6a23c5c573", null ]
];