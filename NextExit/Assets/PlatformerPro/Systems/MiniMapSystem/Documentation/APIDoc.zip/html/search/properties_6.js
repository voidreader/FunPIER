var searchData=
[
  ['overridesprite',['OverrideSprite',['../classjnamobile_1_1mmm_1_1_map_room_data.html#a90054a644f2f2a8fbc5733ea7cc6209d',1,'jnamobile::mmm::MapRoomData']]]
];
