var searchData=
[
  ['maproom',['MapRoom',['../classjnamobile_1_1mmm_1_1_map_room_data.html#a0677c4ea7068bb2ecdf3d7d4ed364fe1',1,'jnamobile::mmm::MapRoomData']]]
];
