var searchData=
[
  ['onenteredroom',['OnEnteredRoom',['../classjnamobile_1_1mmm_1_1_map_manager.html#a044bcb0612a91e2adf5a5fe4a3df71c1',1,'jnamobile::mmm::MapManager']]],
  ['ongui',['OnGUI',['../class_m_m_m_sprite_assigner.html#a448a4c8104f2c10da5608fcb8b7431b2',1,'MMMSpriteAssigner']]],
  ['onleftroom',['OnLeftRoom',['../classjnamobile_1_1mmm_1_1_map_manager.html#aeef0fb43cab41f84dec4866b286d5528',1,'jnamobile::mmm::MapManager']]],
  ['onpointofinterestadded',['OnPointOfInterestAdded',['../classjnamobile_1_1mmm_1_1_map_manager.html#ac497b2a4af9186353ff5830100138dfe',1,'jnamobile::mmm::MapManager']]],
  ['onpointofinterestremoved',['OnPointOfInterestRemoved',['../classjnamobile_1_1mmm_1_1_map_manager.html#a0eee06dc9b03646ec575a670cc5ee5c6',1,'jnamobile::mmm::MapManager']]],
  ['onrevealedroom',['OnRevealedRoom',['../classjnamobile_1_1mmm_1_1_map_manager.html#a995165ec0b90dbe4a468f1dac064dc6a',1,'jnamobile.mmm.MapManager.OnRevealedRoom(MapRoom room)'],['../classjnamobile_1_1mmm_1_1_map_manager.html#a3356fc481a6ab970f5b03fdc1dfb08f6',1,'jnamobile.mmm.MapManager.OnRevealedRoom(MapRoomData data)']]],
  ['outofrange',['OutOfRange',['../classjnamobile_1_1mmm_1_1_map_room.html#a0be450c9d800f335a68de0707bcc117d',1,'jnamobile::mmm::MapRoom']]],
  ['overridesprite',['OverrideSprite',['../classjnamobile_1_1mmm_1_1_map_room_data.html#a90054a644f2f2a8fbc5733ea7cc6209d',1,'jnamobile.mmm.MapRoomData.OverrideSprite()'],['../classjnamobile_1_1mmm_1_1_map_room.html#a2c2ba4308ad692842ea97999a2b524f2',1,'jnamobile.mmm.MapRoom.overrideSprite()']]],
  ['overridespritename',['overrideSpriteName',['../classjnamobile_1_1mmm_1_1_map_room.html#a3a4f2d084cfedc02ea8acedf50e5d92b',1,'jnamobile::mmm::MapRoom']]]
];
