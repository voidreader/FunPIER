var searchData=
[
  ['icon',['icon',['../classjnamobile_1_1mmm_1_1_point_of_interest_data.html#a704aaed3c4ab39589620f4c0bb561806',1,'jnamobile.mmm.PointOfInterestData.icon()'],['../classjnamobile_1_1mmm_1_1_point_of_interest.html#a55fd13222f0c0592f058f61993d00379',1,'jnamobile.mmm.PointOfInterest.icon()']]],
  ['iconname',['iconName',['../classjnamobile_1_1mmm_1_1_point_of_interest.html#aca3d5621651b2a38d0a692a0362c0248',1,'jnamobile::mmm::PointOfInterest']]],
  ['ignorecolor',['ignoreColor',['../classjnamobile_1_1mmm_1_1_u_i_map_content.html#ab7e194f8ac30cf719c4bbb984ae7007d',1,'jnamobile::mmm::UIMapContent']]],
  ['ignorepointcolor',['ignorePointColor',['../classjnamobile_1_1mmm_1_1_u_i_map_content.html#a8e1a090a343baf39c85cdce922d3ff01',1,'jnamobile::mmm::UIMapContent']]],
  ['ignorepointspriteoverride',['ignorePointSpriteOverride',['../classjnamobile_1_1mmm_1_1_u_i_map_content.html#a7748a2ec3a5d4c115077916ab0be0378',1,'jnamobile::mmm::UIMapContent']]],
  ['ignorespriteoverride',['ignoreSpriteOverride',['../classjnamobile_1_1mmm_1_1_u_i_map_content.html#a591819164620b82d16500c8c91a804f7',1,'jnamobile::mmm::UIMapContent']]],
  ['init',['Init',['../classjnamobile_1_1mmm_1_1_u_i_map_content.html#a71e8b6022cfdd7deb64f653f8baa28e3',1,'jnamobile.mmm.UIMapContent.Init()'],['../classjnamobile_1_1mmm_1_1_u_i_point_of_interest.html#ac8c6ab9720c4ddf6f59bc3c2067eddcb',1,'jnamobile.mmm.UIPointOfInterest.Init()'],['../classjnamobile_1_1mmm_1_1_u_i_room.html#a9a27c8f7d4ccc6bfbd70ba5841b1c854',1,'jnamobile.mmm.UIRoom.Init()']]],
  ['instance',['Instance',['../classjnamobile_1_1mmm_1_1_map_manager.html#ab99e4a664eaddd6028f8f28eb126c9ee',1,'jnamobile.mmm.MapManager.Instance()'],['../classjnamobile_1_1mmm_1_1_sprite_dictionary.html#aba984f3d1d6606ed56dc5cb417b97625',1,'jnamobile.mmm.SpriteDictionary.Instance()'],['../classjnamobile_1_1mmm_1_1_map_manager.html#acd0cb7f0a704511ff659180b1fb7edf6',1,'jnamobile.mmm.MapManager.instance()']]],
  ['isdynamic',['isDynamic',['../classjnamobile_1_1mmm_1_1_point_of_interest_data.html#ad8e4aeab44b15499b702750d4ad78b83',1,'jnamobile.mmm.PointOfInterestData.isDynamic()'],['../classjnamobile_1_1mmm_1_1_point_of_interest.html#a61cce5defdcc688ca843e7472aa3d89a',1,'jnamobile.mmm.PointOfInterest.isDynamic()']]],
  ['isrevealed',['isRevealed',['../classjnamobile_1_1mmm_1_1_map_room.html#a794243f5a1fe11fea98eca4067b0f5a1',1,'jnamobile::mmm::MapRoom']]],
  ['isscrolling',['isScrolling',['../classjnamobile_1_1mmm_1_1_u_i_map_content.html#ad08f54ee535e1c0d32650df4f573f978',1,'jnamobile::mmm::UIMapContent']]],
  ['items',['items',['../classjnamobile_1_1mmm_1_1_sprite_dictionary.html#a6853f0ccf8338670760342d369a1fc05',1,'jnamobile::mmm::SpriteDictionary']]]
];
