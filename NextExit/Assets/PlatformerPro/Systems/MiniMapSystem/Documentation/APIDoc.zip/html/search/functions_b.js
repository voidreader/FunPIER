var searchData=
[
  ['pointofinterestdata',['PointOfInterestData',['../classjnamobile_1_1mmm_1_1_point_of_interest_data.html#a0ae2e246d642c35ecd57051ced3de103',1,'jnamobile.mmm.PointOfInterestData.PointOfInterestData()'],['../classjnamobile_1_1mmm_1_1_point_of_interest_data.html#a45784c9a60168ff05baefcfb36aad3c4',1,'jnamobile.mmm.PointOfInterestData.PointOfInterestData(PointOfInterest poi)']]],
  ['pointofinteresteventargs',['PointOfInterestEventArgs',['../classjnamobile_1_1mmm_1_1_point_of_interest_event_args.html#a3823ec21383fb9c66e7918418c5172fd',1,'jnamobile::mmm::PointOfInterestEventArgs']]]
];
