var searchData=
[
  ['maproomdata',['MapRoomData',['../classjnamobile_1_1mmm_1_1_map_room_data.html#add255e640aef0cca3942242ff83c6ca1',1,'jnamobile.mmm.MapRoomData.MapRoomData()'],['../classjnamobile_1_1mmm_1_1_map_room_data.html#a650d54254f07ee21a2bfa443e6a092b8',1,'jnamobile.mmm.MapRoomData.MapRoomData(MapRoom mapRoom)']]]
];
