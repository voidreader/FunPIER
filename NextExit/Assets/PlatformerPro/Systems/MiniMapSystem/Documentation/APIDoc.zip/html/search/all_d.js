var searchData=
[
  ['nameproperty',['nameProperty',['../class_sprite_assigner_attribute.html#a2488b0b36409bebb1d5c05b193243d9c',1,'SpriteAssignerAttribute']]],
  ['needstosave',['needsToSave',['../classjnamobile_1_1mmm_1_1_map_manager.html#ab8434649f1508d1f01b1054bfe45149e',1,'jnamobile::mmm::MapManager']]]
];
