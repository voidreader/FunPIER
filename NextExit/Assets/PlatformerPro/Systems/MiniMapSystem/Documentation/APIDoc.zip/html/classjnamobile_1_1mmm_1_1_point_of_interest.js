var classjnamobile_1_1mmm_1_1_point_of_interest =
[
    [ "category", "classjnamobile_1_1mmm_1_1_point_of_interest.html#af3ef0b3a6a40e37bc98b0b6b69b8edc7", null ],
    [ "color", "classjnamobile_1_1mmm_1_1_point_of_interest.html#a7b822fc30cc2a97f516e5476a70fa90c", null ],
    [ "fqn", "classjnamobile_1_1mmm_1_1_point_of_interest.html#aeaefc4a107b87c3a41deeb5b6acb6f61", null ],
    [ "hidden", "classjnamobile_1_1mmm_1_1_point_of_interest.html#a0724fa64f80a822ce1f85e1297cf1c41", null ],
    [ "icon", "classjnamobile_1_1mmm_1_1_point_of_interest.html#a55fd13222f0c0592f058f61993d00379", null ],
    [ "iconName", "classjnamobile_1_1mmm_1_1_point_of_interest.html#aca3d5621651b2a38d0a692a0362c0248", null ],
    [ "isDynamic", "classjnamobile_1_1mmm_1_1_point_of_interest.html#a61cce5defdcc688ca843e7472aa3d89a", null ],
    [ "label", "classjnamobile_1_1mmm_1_1_point_of_interest.html#aa5d0871ff277f2a11c96f3b408389de2", null ],
    [ "poiName", "classjnamobile_1_1mmm_1_1_point_of_interest.html#af02edd3d12c46f83a269c3d5ec4413de", null ],
    [ "revealed", "classjnamobile_1_1mmm_1_1_point_of_interest.html#a132691375e5adc413ca553ef0329196c", null ],
    [ "FullyQualifiedRoomName", "classjnamobile_1_1mmm_1_1_point_of_interest.html#afc8d7f995adbfbd120d5d05acd8954e4", null ],
    [ "PoiName", "classjnamobile_1_1mmm_1_1_point_of_interest.html#aba3967edf93ad29d4f1c23a256fd92b7", null ],
    [ "Position", "classjnamobile_1_1mmm_1_1_point_of_interest.html#a902736271409b8487e1eac11c7911122", null ]
];