var classjnamobile_1_1mmm_1_1_room_event_args =
[
    [ "RoomEventArgs", "classjnamobile_1_1mmm_1_1_room_event_args.html#a7f34e471d0bda296b33838c2d3e8c36c", null ],
    [ "Room", "classjnamobile_1_1mmm_1_1_room_event_args.html#a53ffdbfe096b65fbd3ee4c549527cc9b", null ]
];