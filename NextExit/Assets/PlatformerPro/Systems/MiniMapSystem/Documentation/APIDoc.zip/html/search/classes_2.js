var searchData=
[
  ['roomeventargs',['RoomEventArgs',['../classjnamobile_1_1mmm_1_1_room_event_args.html',1,'jnamobile::mmm']]]
];
