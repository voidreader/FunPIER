var searchData=
[
  ['savedata',['SaveData',['../classjnamobile_1_1mmm_1_1_save_data.html',1,'jnamobile::mmm']]],
  ['spriteassignerattribute',['SpriteAssignerAttribute',['../class_sprite_assigner_attribute.html',1,'']]],
  ['spritedictionary',['SpriteDictionary',['../classjnamobile_1_1mmm_1_1_sprite_dictionary.html',1,'jnamobile::mmm']]]
];
