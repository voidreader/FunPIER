var searchData=
[
  ['savegameid',['SaveGameId',['../classjnamobile_1_1mmm_1_1_map_manager.html#a7d21c38d08e41b8b39a225759ddd19b2',1,'jnamobile::mmm::MapManager']]]
];
