var searchData=
[
  ['fromkey',['FromKey',['../classjnamobile_1_1mmm_1_1_map_room_data.html#aecadcbb43aeeeb08653c4ede6571e980',1,'jnamobile.mmm.MapRoomData.FromKey()'],['../classjnamobile_1_1mmm_1_1_point_of_interest_data.html#a2fceeb3e9b7923681c3f792a257402e1',1,'jnamobile.mmm.PointOfInterestData.FromKey()']]]
];
