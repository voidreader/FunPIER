var searchData=
[
  ['revealedroom',['RevealedRoom',['../classjnamobile_1_1mmm_1_1_map_manager.html#ab855b2f65eb8005ac74fc0cb4e9ac2fc',1,'jnamobile::mmm::MapManager']]]
];
