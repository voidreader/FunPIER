var searchData=
[
  ['_5fposition',['_position',['../classjnamobile_1_1mmm_1_1_map_room_data.html#a85182c4be0614f0beeac97abbb3b4eea',1,'jnamobile::mmm::MapRoomData']]]
];
