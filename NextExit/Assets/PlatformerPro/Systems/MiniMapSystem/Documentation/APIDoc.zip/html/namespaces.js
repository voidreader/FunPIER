var namespaces =
[
    [ "jnamobile", "namespacejnamobile.html", "namespacejnamobile" ]
];