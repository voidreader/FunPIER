var searchData=
[
  ['fullyqualifiedroomname',['FullyQualifiedRoomName',['../classjnamobile_1_1mmm_1_1_map_room.html#a3c8069060cd23fb685c6fe8406f1643d',1,'jnamobile.mmm.MapRoom.FullyQualifiedRoomName()'],['../classjnamobile_1_1mmm_1_1_point_of_interest.html#afc8d7f995adbfbd120d5d05acd8954e4',1,'jnamobile.mmm.PointOfInterest.FullyQualifiedRoomName()']]]
];
