var searchData=
[
  ['revealed',['revealed',['../classjnamobile_1_1mmm_1_1_map_room_data.html#aae8a621c537af65d6920521548638ea3',1,'jnamobile.mmm.MapRoomData.revealed()'],['../classjnamobile_1_1mmm_1_1_point_of_interest_data.html#ac35dd03ef3501caeeaab62e53360a414',1,'jnamobile.mmm.PointOfInterestData.revealed()'],['../classjnamobile_1_1mmm_1_1_point_of_interest.html#a132691375e5adc413ca553ef0329196c',1,'jnamobile.mmm.PointOfInterest.revealed()']]],
  ['room',['room',['../classjnamobile_1_1mmm_1_1_u_i_point_of_interest.html#ac06cc005910a94db09037458dcbbba4a',1,'jnamobile.mmm.UIPointOfInterest.room()'],['../classjnamobile_1_1mmm_1_1_u_i_room.html#a7a7d60f41f3264f9839dac4a7cad7cb6',1,'jnamobile.mmm.UIRoom.room()']]],
  ['roomname',['roomName',['../classjnamobile_1_1mmm_1_1_map_room.html#aa0c6c6aae0ed298b16fea9d3063742ac',1,'jnamobile::mmm::MapRoom']]],
  ['roomoffset',['roomOffset',['../classjnamobile_1_1mmm_1_1_u_i_map_content.html#a4aaa28979a2a7df750219c0effc08424',1,'jnamobile::mmm::UIMapContent']]],
  ['roomprefab',['roomPrefab',['../classjnamobile_1_1mmm_1_1_u_i_map_content.html#a28c9f707c50739f824cf762d83de9969',1,'jnamobile::mmm::UIMapContent']]],
  ['rooms',['rooms',['../classjnamobile_1_1mmm_1_1_save_data.html#a131e0de3028565c2c27ae85efe673fc7',1,'jnamobile::mmm::SaveData']]],
  ['roomuicomponents',['roomUiComponents',['../classjnamobile_1_1mmm_1_1_u_i_map_content.html#a0510039593b779655661bfd244d68ac0',1,'jnamobile::mmm::UIMapContent']]],
  ['rotatewithplayer',['rotateWithPlayer',['../classjnamobile_1_1mmm_1_1_u_i_player_indicator.html#a5614bb85a74d0285b260b4ed47194f05',1,'jnamobile::mmm::UIPlayerIndicator']]],
  ['rt',['rt',['../classjnamobile_1_1mmm_1_1_u_i_player_indicator.html#a42c6a237bf51b5fe911117a1963f29ea',1,'jnamobile::mmm::UIPlayerIndicator']]]
];
