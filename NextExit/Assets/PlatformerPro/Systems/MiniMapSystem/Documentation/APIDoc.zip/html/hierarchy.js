var hierarchy =
[
    [ "EventArgs", null, [
      [ "jnamobile.mmm.RoomEventArgs", "classjnamobile_1_1mmm_1_1_room_event_args.html", [
        [ "jnamobile.mmm.PointOfInterestEventArgs", "classjnamobile_1_1mmm_1_1_point_of_interest_event_args.html", null ]
      ] ]
    ] ],
    [ "jnamobile.mmm.MapRoomData", "classjnamobile_1_1mmm_1_1_map_room_data.html", null ],
    [ "MonoBehaviour", null, [
      [ "jnamobile.mmm.MapManager", "classjnamobile_1_1mmm_1_1_map_manager.html", null ],
      [ "jnamobile.mmm.MapRoom", "classjnamobile_1_1mmm_1_1_map_room.html", null ],
      [ "jnamobile.mmm.PointOfInterest", "classjnamobile_1_1mmm_1_1_point_of_interest.html", null ],
      [ "jnamobile.mmm.SpriteDictionary", "classjnamobile_1_1mmm_1_1_sprite_dictionary.html", null ],
      [ "jnamobile.mmm.UIBaseMapComponent", "classjnamobile_1_1mmm_1_1_u_i_base_map_component.html", [
        [ "jnamobile.mmm.UIPointOfInterest", "classjnamobile_1_1mmm_1_1_u_i_point_of_interest.html", null ],
        [ "jnamobile.mmm.UIRoom", "classjnamobile_1_1mmm_1_1_u_i_room.html", null ]
      ] ],
      [ "jnamobile.mmm.UICurrentRoomName", "classjnamobile_1_1mmm_1_1_u_i_current_room_name.html", null ],
      [ "jnamobile.mmm.UIMapContent", "classjnamobile_1_1mmm_1_1_u_i_map_content.html", null ],
      [ "jnamobile.mmm.UIPlayerIndicator", "classjnamobile_1_1mmm_1_1_u_i_player_indicator.html", null ]
    ] ],
    [ "jnamobile.mmm.PointOfInterestData", "classjnamobile_1_1mmm_1_1_point_of_interest_data.html", null ],
    [ "PropertyAttribute", null, [
      [ "SpriteAssignerAttribute", "class_sprite_assigner_attribute.html", null ]
    ] ],
    [ "PropertyDrawer", null, [
      [ "MMMSpriteAssigner", "class_m_m_m_sprite_assigner.html", null ]
    ] ],
    [ "jnamobile.mmm.SaveData", "classjnamobile_1_1mmm_1_1_save_data.html", null ]
];