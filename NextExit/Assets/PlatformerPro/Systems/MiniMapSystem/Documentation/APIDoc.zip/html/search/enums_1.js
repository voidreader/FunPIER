var searchData=
[
  ['rotationmatchtype',['RotationMatchType',['../namespacejnamobile_1_1mmm.html#a2071f1d66e8f2387fe83ac48b50b8499',1,'jnamobile::mmm']]]
];
