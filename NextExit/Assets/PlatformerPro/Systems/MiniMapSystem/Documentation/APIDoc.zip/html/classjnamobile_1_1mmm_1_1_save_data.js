var classjnamobile_1_1mmm_1_1_save_data =
[
    [ "pois", "classjnamobile_1_1mmm_1_1_save_data.html#a547edcc6aecbc22ed65c565f82481852", null ],
    [ "rooms", "classjnamobile_1_1mmm_1_1_save_data.html#a131e0de3028565c2c27ae85efe673fc7", null ]
];