var searchData=
[
  ['init',['Init',['../classjnamobile_1_1mmm_1_1_u_i_map_content.html#a71e8b6022cfdd7deb64f653f8baa28e3',1,'jnamobile.mmm.UIMapContent.Init()'],['../classjnamobile_1_1mmm_1_1_u_i_point_of_interest.html#ac8c6ab9720c4ddf6f59bc3c2067eddcb',1,'jnamobile.mmm.UIPointOfInterest.Init()'],['../classjnamobile_1_1mmm_1_1_u_i_room.html#a9a27c8f7d4ccc6bfbd70ba5841b1c854',1,'jnamobile.mmm.UIRoom.Init()']]]
];
