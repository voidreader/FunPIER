var _points_of_interest_rendering_type_8cs =
[
    [ "PointsOfInterestRenderingType", "_points_of_interest_rendering_type_8cs.html#a15d7278e69d66964d64788664332b3e2", [
      [ "DONT_SHOW", "_points_of_interest_rendering_type_8cs.html#a15d7278e69d66964d64788664332b3e2a9c1c48e8856ffa1d336ccd058fd7bac0", null ],
      [ "SHOW_IN_CENTRE", "_points_of_interest_rendering_type_8cs.html#a15d7278e69d66964d64788664332b3e2aef5985aa58962046a694b5f38485fbda", null ],
      [ "SHOW_IN_POSITION", "_points_of_interest_rendering_type_8cs.html#a15d7278e69d66964d64788664332b3e2a822eff2ae3bfa1565242d87437897461", null ],
      [ "SHOW_IN_POSITION_WITH_LABEL", "_points_of_interest_rendering_type_8cs.html#a15d7278e69d66964d64788664332b3e2ae3ee416c022d917396bcafa50e317602", null ]
    ] ]
];