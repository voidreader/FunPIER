var class_sprite_assigner_attribute =
[
    [ "SpriteAssignerAttribute", "class_sprite_assigner_attribute.html#ad589e2c2d7e1c81a439e6c3cbbc70d5f", null ],
    [ "nameProperty", "class_sprite_assigner_attribute.html#a2488b0b36409bebb1d5c05b193243d9c", null ]
];