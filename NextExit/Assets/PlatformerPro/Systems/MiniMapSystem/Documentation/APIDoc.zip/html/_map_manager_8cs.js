var _map_manager_8cs =
[
    [ "MapManager", "classjnamobile_1_1mmm_1_1_map_manager.html", "classjnamobile_1_1mmm_1_1_map_manager" ],
    [ "WorldOrientation", "_map_manager_8cs.html#aa93e280e165b05f61d8b955c9e1e368d", [
      [ "X_Y", "_map_manager_8cs.html#aa93e280e165b05f61d8b955c9e1e368da72fa45c61dc40121aa4b4dcc30e90820", null ],
      [ "X_Z", "_map_manager_8cs.html#aa93e280e165b05f61d8b955c9e1e368dab69daf3a8f735f3933120c5ed740e085", null ]
    ] ]
];