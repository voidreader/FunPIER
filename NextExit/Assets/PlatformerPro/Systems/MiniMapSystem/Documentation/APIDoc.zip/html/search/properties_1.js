var searchData=
[
  ['clearlyoutdistance',['ClearlyOutDistance',['../classjnamobile_1_1mmm_1_1_map_manager.html#aefb0e4340de0ab4dadf7be92a03c1bdd',1,'jnamobile::mmm::MapManager']]],
  ['currentroom',['CurrentRoom',['../classjnamobile_1_1mmm_1_1_map_manager.html#ab11e23892c536c86a63bd476a572380e',1,'jnamobile::mmm::MapManager']]]
];
