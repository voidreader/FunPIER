var classjnamobile_1_1mmm_1_1_u_i_point_of_interest =
[
    [ "Init", "classjnamobile_1_1mmm_1_1_u_i_point_of_interest.html#ac8c6ab9720c4ddf6f59bc3c2067eddcb", null ],
    [ "UpdatePosition", "classjnamobile_1_1mmm_1_1_u_i_point_of_interest.html#a87091e9db09c2acb0d5cacea1ef5d67f", null ],
    [ "UpdateVisibilityAndPosition", "classjnamobile_1_1mmm_1_1_u_i_point_of_interest.html#a0ef036022ed7d44dadba90ea24894b18", null ],
    [ "poi", "classjnamobile_1_1mmm_1_1_u_i_point_of_interest.html#abea3e077ec0d4eadebc8903d6724930f", null ],
    [ "room", "classjnamobile_1_1mmm_1_1_u_i_point_of_interest.html#ac06cc005910a94db09037458dcbbba4a", null ]
];