var namespacejnamobile =
[
    [ "mmm", "namespacejnamobile_1_1mmm.html", "namespacejnamobile_1_1mmm" ]
];