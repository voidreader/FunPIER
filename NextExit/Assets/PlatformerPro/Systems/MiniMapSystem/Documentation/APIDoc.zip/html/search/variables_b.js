var searchData=
[
  ['overridesprite',['overrideSprite',['../classjnamobile_1_1mmm_1_1_map_room.html#a2c2ba4308ad692842ea97999a2b524f2',1,'jnamobile::mmm::MapRoom']]],
  ['overridespritename',['overrideSpriteName',['../classjnamobile_1_1mmm_1_1_map_room.html#a3a4f2d084cfedc02ea8acedf50e5d92b',1,'jnamobile::mmm::MapRoom']]]
];
