var searchData=
[
  ['pointofinterestadded',['PointOfInterestAdded',['../classjnamobile_1_1mmm_1_1_map_manager.html#a98cb25f0eda94c62af515ed9768b54f5',1,'jnamobile::mmm::MapManager']]],
  ['pointofinterestremoved',['PointOfInterestRemoved',['../classjnamobile_1_1mmm_1_1_map_manager.html#aeb953854f26d0eb5696819335305e7d4',1,'jnamobile::mmm::MapManager']]]
];
